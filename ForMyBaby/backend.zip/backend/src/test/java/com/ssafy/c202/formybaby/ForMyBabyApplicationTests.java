package com.ssafy.c202.formybaby;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForMyBabyApplicationTests {

    @Test
    void contextLoads() {
    }

}
