package com.ssafy.c202.formybaby.global.jpaEnum;

public enum Role {
    Mother ,
    Father ,
    Brother ,
    Sister ,
    Grandfather,
    Grandmother ,
    Others
}
