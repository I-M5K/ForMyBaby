package com.ssafy.c202.formybaby.user.dto.request;

public record roleUpdateRequest (
        String familyCode
) {}