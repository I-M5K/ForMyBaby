package com.ssafy.c202.formybaby.user.dto.request;


public record UserUpdateRequest(
        String userName,
        String role

) {}
