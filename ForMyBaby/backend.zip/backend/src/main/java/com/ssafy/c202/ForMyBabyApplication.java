package com.ssafy.c202;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForMyBabyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForMyBabyApplication.class, args);
	}

}
