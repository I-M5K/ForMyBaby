package com.ssafy.c202.formybaby.user.dto.request;

public record FamilyCodeUpdateRequest (
        String familyCode
) {}
