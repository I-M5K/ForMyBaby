package com.ssafy.c202.formybaby.global.jpaEnum;

public enum SleepCategory {
    nap, // 낮잠
    sleep // 밤잠
}
