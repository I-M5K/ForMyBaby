package com.ssafy.c202.formybaby.global.jpaEnum;

public enum BabyGender {
    male,
    female
}
