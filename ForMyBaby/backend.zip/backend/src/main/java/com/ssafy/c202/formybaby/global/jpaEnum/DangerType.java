package com.ssafy.c202.formybaby.global.jpaEnum;

public enum DangerType {
    flip,
    insert_into_mouth,
    stand_up,
    exit_area
}
